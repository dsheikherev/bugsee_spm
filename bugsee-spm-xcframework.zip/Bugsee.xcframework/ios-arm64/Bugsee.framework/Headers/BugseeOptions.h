//
//  BugseeOptions.h
//  Bugsee
//
//  Created by ANDREY KOVALEV on 13.09.2017.
//  Copyright © 2016-2026 Bugsee. All rights reserved.
//

#ifndef BUGSEE_OPTIONS_H
#define BUGSEE_OPTIONS_H

#import <Foundation/Foundation.h>
#import "BugseeConstants.h"

@interface BugseeOptions : NSObject<NSCoding>

+ (nullable BugseeOptions *)optionsFrom:(NSDictionary *_Nullable)options;

+ (nonnull BugseeOptions *)defaultOptions;

/**
 * Update with old style options.
 * example of usage:
 *
 * BugseeOptions * options = [BugseeOptions defaultOptions];
 * NSDictionary * dict =         options = @{BugseeMaxRecordingTimeKey   : @60,
                                             BugseeShakeToReportKey      : BugseeTrue,
                                             BugseeScreenshotToReportKey : BugseeTrue,
                                             BugseeStatusBarInfoKey      : BugseeTrue,
                                             ...
                                             BugseeCrashReportKey        : BugseeTrue
                                            };
 * [options updateWithOptions:dict];
 *
 * Keys for old style options you can find in BugseeConstants.h
 * Options documentation: https://docs.bugsee.com/sdk/ios/configuration/
 */
- (void)updateLaunchOptions:(nonnull NSDictionary *)dict;

/**
 * Use to change bugsee style to Light, Dusk or Based on status bar
 * Default: BugseeStyleSystem
 */
@property(nonatomic, assign) BugseeStyle bugseeStyle;

/**
 * Use this option to change frame rate to Low or High
 * Default: BugseeSeverityHigh
 */
@property(nonatomic, assign) BugseeFrameRate framerate;

/**
 * Priority for crashes
 * Default: BugseeSeverityBlocker
 */
@property(nonatomic, assign) BugseeSeverityLevel defaultCrashPriority;

/**
 * Priority for bugs
 * Default: BugseeSeverityHigh
 */
@property(nonatomic, assign) BugseeSeverityLevel defaultBugPriority;

/**
 * Priority for errors
 * Default: BugseeSeverityHigh
 */
@property(nonatomic, assign) BugseeSeverityLevel defaultErrorPriority;

/**
 * Shake gesture to trigger report
 * Default: NO
 */
@property(nonatomic, assign) BOOL shakeToReport;

/**
 * Screenshot key to trigger report
 * Default: YES
 */
@property(nonatomic, assign) BOOL screenshotToReport;

/**
 * Catch and report application crashes 
 * IOS allows only one crash detector to be active at a time, if you insist on using an 
 * alternative solution for handling crashes, you might want to use this option and disable 
 * Bugsee from taking over.
 * Default: YES
 */
@property(nonatomic, assign) BOOL crashReport;

/**
 * Detect app exit triggered by user (i.e. when app's preview is swiped up
 * to close the app). If TRUE, Bugsee will detect app exit and create a report.
 * Default: NO
 */
@property(nonatomic, assign) BOOL detectAppExit;

/**
 Whether bug summary is required. If set to YES, then report form will prevent submission while
 summary field is empty.
 Default: NO
 */
@property(nonatomic, assign) BOOL reportSummaryRequired;

/**
 Whether bug description is required. If set to YES, then report form will prevent submission while
 description field is empty.
 Default: NO
 */
@property(nonatomic, assign) BOOL reportDescriptionRequired;

/**
 Whether email is required. If set to YES, then report form will prevent submission while
 email field is empty.
 Default: NO
 */
@property(nonatomic, assign) BOOL reportEmailRequired;

/**
 * Controls whether labels input field is available in bug reporting UI.
 * Default: NO
 */
@property(nonatomic, assign) BOOL reportLabelsEnabled;

/**
 * Controls whether Labels input field must be filled to submit data in bug reporting UI.
 * Default: NO
 */
@property(nonatomic, assign) BOOL reportLabelsRequired;

/**
 * Detect abnormal termination | experimental method, read more - https://docs.bugsee.com/sdk/ios/app-kills |
 * Default: NO
 */
@property(nonatomic, assign) BOOL killDetection;

/**
 * Detect crash happened on application launch.
 * Detected crash will be sent synchronously on application restart (this can freeze Main Thread).
 * Default: NO
 */
@property(nonatomic, assign) BOOL appLaunchCrashDetection;

/**
 * Capture network traffic
 * Default: YES
 */
@property(nonatomic, assign) BOOL monitorNetwork;

/**
 * Automatically sanitize sensitive data (PII) from captured network events.
 * Applies only when no custom network filter (block or delegate) is set.
 * Redacts values for known sensitive keys in URL query parameters, HTTP headers, and JSON bodies.
 * Default: YES
 */
@property(nonatomic, assign) BOOL sanitizeNetworkData;

/**
 * Capture web-sockets traffic
 * Default: YES
 */
@property(nonatomic, assign) BOOL monitorWebSocket;

/**
 * Info about pending reports and current recording state.
 * Default: NO
 */
@property(nonatomic, assign) BOOL statusBarInfo;

/**
 * Enable video recording
 * Default: YES
 */
@property(nonatomic, assign) BOOL videoEnabled;

/**
 * Screenshot which is attached to the report
 * Default: When videoEnabled it's true, but if videoEnabled == false it's false
 */
@property(nonatomic, assign) BOOL screenshotEnabled;

/**
 * If set to true, enables capturing of view hierarchy upon bug reporting
 * Default: true
 */
@property(nonatomic, assign) BOOL viewHierarchyEnabled;

/**
 * Turn on Mach exception handler.
 * Default: NO
 */
@property(nonatomic, assign) BOOL enableMachExceptions;

/**
* Enable on device symbolication for system frames.
* Default: NO
*/
@property(nonatomic, assign) BOOL enableOnDeviceSymbolication;

/**
 * Allow user to modify priority when reporting manual
 * Default: NO
 */
@property(nonatomic, assign) BOOL reportPrioritySelector;

/**
 * Automatically capture all console logs
 * Default: YES
 */
@property(nonatomic, assign) BOOL captureLogs;

/**
 * Automatically capture OSLog entries
 * Default: NO
 */
@property(nonatomic, assign) BOOL captureOSLogs;

/**
 * Automatically capture AVPlayer driven videos rendered onto AVPlayerLayer
 * Default: NO
 */
@property(nonatomic, assign) BOOL captureAVPlayer;

/**
 * Maximum recording duration
 * Default: 60
 */
@property(nonatomic, assign) int maxRecordingTime;

/**
 * Bugsee network requests allowed only by wifi
 * Default: NO
 */
@property(nonatomic, assign) BOOL wifiOnlyUpload;

/**
 * Capture Device and wifi names.
 * They are shown on the issue screen.
 * Default: NO
 */
@property(nonatomic, assign) BOOL captureDeviceAndNetworkNames;

/**
 * Monitor current bluetooth status
 * NSBluetoothAlwaysUsageDescription info.plist flag needed in ios 13+ versions
 * Default: NO
 */
@property(nonatomic, assign) BOOL monitorBluetoothStatus;

/**
 * Bugsee uses Disk Space APIs with declared reason E174.1<br/>
 * This reason does not allow to send collected information off-device.
 * We recommend to collect such data only in debug/development builds.
 * Default: NO
 */
@property(nonatomic, assign) BOOL monitorDiskSpace;

/**
 * Master switch for the APM (Application Performance Monitoring) subsystem.
 * Controls the in-process span/trace pipeline, which:
 *   - Auto-instruments NSURLSession HTTP requests (one transaction per request);
 *   - Auto-instruments NSData file reads/writes (file.read / file.write spans);
 *   - Auto-instruments NSFileManager create / delete / copy / move / mkdir
 *     operations (file.* spans);
 *   - Exposes the public Bugsee.startTransaction(...) / Bugsee.startSpan(...)
 *     API for manual instrumentation.
 *
 * Captured transactions are written to every Bugsee
 * report bundle. A standalone upload pipeline (gated by `performanceSampleRate`
 * and `performanceAdaptiveSampling`) is reserved for a future revision and
 * is not currently wired.
 *
 * Default: YES
 */
@property(nonatomic, assign) BOOL performanceMonitoring;

/**
 * Sampling rate for standalone APM upload. Range 0.0 – 1.0.
 * Sampling does NOT affect data attached to bug reports — every transaction
 * is included in the bundle regardless of this rate. The rate only gates
 * a future independent upload pipeline (currently not wired).
 * Default: 0.01
 */
@property(nonatomic, assign) float performanceSampleRate;

/**
 * When YES, transactions that lost the static sampling draw can still be
 * promoted into the upload pipeline if they look "interesting" — non-OK
 * status, large duration outliers, or high span complexity.
 * Default: YES
 */
@property(nonatomic, assign) BOOL performanceAdaptiveSampling;

/**
 * Bugsee will avoid using more disk space than specified. <br/>
 * Option has value of int type and should be specified in Mb. Value should not be smaller than 10.
 * Default: 50
 */
@property(nonatomic, assign) int maxDataSize;

/**
 *  The maximal size of network request/response body (in bytes). <br/>
 *  Option has value of int type. Default value is 20480.
 */
@property(nonatomic, assign) int maxNetworkBodySize;

/**
 *  Name of the project target
 */
@property(nonatomic, strong) NSString *_Nullable buildTarget;

/**
 *  debug, release, etc...
 */
@property(nonatomic, strong) NSString *_Nullable buildType;

@property(nonatomic, assign) uint maxFramerate;
@property(nonatomic, assign) uint minFramerate;

/**
 * Increase or decrease quality of video
 * Default: 0 - means not used
 */
@property(nonatomic, assign) float videoScale;

/**
 * Dictionary of launch options specified by user.
 * @return dictionary of options that differ from the default options
 */
- (nullable NSDictionary *)userOptions;

/**
 * Dictionary of all launch options applied to Bugsee.
 * @return dictionary of all options (user-specified and default)
 */
- (nullable NSDictionary *)dictionary;

- (nullable id)objectForKeyedSubscript:(nonnull NSString *)key;

@end

#endif // !BUGSEE_OPTIONS_H
