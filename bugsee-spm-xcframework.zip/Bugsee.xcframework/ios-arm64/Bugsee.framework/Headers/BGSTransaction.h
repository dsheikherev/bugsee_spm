//
//  BGSTransaction.h
//  Bugsee
//
//  Copyright © 2026 Bugsee. All rights reserved.
//

#ifndef BGS_TRANSACTION_H
#define BGS_TRANSACTION_H

#import <Foundation/Foundation.h>
#import "BGSSpan.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * Root span of a trace. Started via `Bugsee.startTransaction(...)`.
 * Owns the trace's identity (traceId), a name, and a sampling decision
 * resolved at creation time. Sampling gates standalone APM upload only —
 * every transaction (sampled or not) is included in bug-report bundles.
 */
NS_SWIFT_NAME(Transaction)
@protocol BGSTransaction <BGSSpan>

@property(readonly) NSString *name;
@property(readonly, getter=isSampled) BOOL sampled;

@end

NS_ASSUME_NONNULL_END

#endif // !BGS_TRANSACTION_H
