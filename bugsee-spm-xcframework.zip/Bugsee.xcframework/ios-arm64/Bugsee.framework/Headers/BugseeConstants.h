//
//  BugseeConstants.h
//  Bugsee
//
//  Created by ANDREY KOVALEV on 10.06.16.
//  Copyright © 2016-2026 Bugsee. All rights reserved.
//

#ifndef BUGSEE_CONSTANTS_H
#define BUGSEE_CONSTANTS_H

#import <Foundation/Foundation.h>
#import "BugseeAttachment.h"

#define BugseeTrue @(YES)
#define BugseeFalse @(NO)

typedef enum : NSUInteger {
    /**
     * Low severity (lowest available)
     */
    BugseeSeverityLow = 1,
    /**
     * Medium severity
     */
    BugseeSeverityMedium = 2,
    /**
     * High severity
     */
    BugseeSeverityHigh = 3,
    /**
     * Critical
     */
    BugseeSeverityCritical = 4,
    /**
     * Blocker (highest available)
     */
    BugseeSeverityBlocker = 5
} BugseeSeverityLevel;

typedef enum : NSUInteger {
    /**
     *
     */
    BugseeFrameRateLow = 1,
    /**
     *
     */
    BugseeFrameRateMedium = 2,
    /**
     *
     */
    BugseeFrameRateHigh = 3
} BugseeFrameRate;

typedef enum : NSUInteger {
    BugseeStyleLight,
    BugseeStyleDusk,
    BugseeStyleBasedOnStatusBar,
    BugseeStyleSystem
} BugseeStyle;

typedef enum : NSUInteger {
    /**
     * Event is dispatched when Bugsee was successfully launched
     */
    BugseeLifecycleEventLaunched,
    /**
     * Event is dispatched when Bugsee is started after beling stopped
     */
    BugseeLifecycleEventStarted,
    /**
     * Event is dispatched when Bugsee is stopped
     */
    BugseeLifecycleEventStopped,
    /**
     * Event is dispatched when Bugsee recording is resumed after being paused
     */
    BugseeLifecycleEventResumed,
    /**
     * Event is dispatched when Bugsee recording is paused
     */
    BugseeLifecycleEventPaused,
    /**
     * Event is dispatched when Bugsee is launched and pending crash report is
     * discovered. That usually means that app was relaunched after crash.
     */
    BugseeLifecycleEventRelaunchedAfterCrash,
    /**
     * Event is dispatched before the reporting UI is shown
     */
    BugseeLifecycleEventBeforeReportShown,
    /**
     * Event is dispatched when reporting UI is shown
     */
    BugseeLifecycleEventAfterReportShown,
    /**
     * Event is dispatched when report is about to be uploaded to the server
     */
    BugseeLifecycleEventBeforeReportUploaded,
    /**
     * Event is dispatched when report was successfully uploaded to the server
     */
    BugseeLifecycleEventAfterReportUploaded,
    /**
     * Event is dispatched before the Feedback controller is shown
     */
    BugseeLifecycleEventBeforeFeedbackShown,
    /**
     * Event is dispatched after the Feedback controller is shown
     */
    BugseeLifecycleEventAfterFeedbackShown,
    /**
     * Event is dispatched before the bug/crash/error report assembly starts
     */
    BugseeLifecycleEventBeforeReportAssembled,
    /**
     * Event is dispatched after the bug/crash/error report assembly completes
     */
    BugseeLifecycleEventAfterReportAssembled,
    /**
     * Event is dispatched after bug/error/crash report upload failed
     * and will be retried in the future
     */
    BugseeLifecycleEventReportUploadFailedWithFutureRetry,
    /**
     * Event is dispatched after multiple bug/error/crash report upload
     * attempts ended with failure. It indicates no more attempts will
     * be taken and the report will not be uploaded.
     */
    BugseeLifecycleEventReportUploadFailed
} BugseeLifecycleEventType;

typedef enum: NSUInteger {
    /**
     * No encryption. Collected data is stored as is.
     */
    BugseeDataEncryptionNone,
    /**
     * Encryption keys are stored on device using a  Secure
     * Enclave, thus protecting it from being extracted.
     */
    BugseeDataEncryptionOnDevice,
    /**
     * Collected data is encrypted at rest and in transit using a one
     * time ephemeral key that is only available in memory during
     * recording and is never stored on the device. The data can only
     * be decrypted on the server (never on device), thus some
     * functionality may be missing (e.x video preview)
     */
    BugseeDataEncryptionEndToEnd
} BugseeDataEncryptionMode;

@class BugseeNetworkEvent;
@class BugseeLogEvent;
@class BugseeExtendedReport;

typedef void (^BugseeEmptyBlock)(void) NS_SWIFT_SENDABLE;

typedef void (^BugseeStartedBlock)(BOOL success) NS_SWIFT_SENDABLE;

typedef void (^BugseeStoppedBlock)(void) NS_SWIFT_SENDABLE;

typedef void (^BugseeLogFilterDecisionBlock)(BugseeLogEvent *_Nullable event) NS_SWIFT_SENDABLE;

typedef void (^BugseeNetworkFilterDecisionBlock)(BugseeNetworkEvent *_Nullable event) NS_SWIFT_SENDABLE;

typedef void (^BugseeAttachmentsDecisionBlock)(NSArray<BugseeAttachment *> *_Nullable attachments) NS_SWIFT_SENDABLE;

typedef void (^BugseeNetworkEventFilterBlock)(BugseeNetworkEvent *_Nonnull event, BugseeNetworkFilterDecisionBlock _Nonnull decisionBlock) NS_SWIFT_SENDABLE;

typedef void (^BugseeExtendedReportBlock)(BugseeExtendedReport *_Nullable report) NS_SWIFT_SENDABLE;

typedef void (^BugseeAdditionalDataCaptureBlock)(NSData *_Nullable additionalData) NS_SWIFT_SENDABLE;

typedef void (^BugseeDeleteCollectedDataCompletionBlock)(BOOL success) NS_SWIFT_SENDABLE;

/**
 *  BugseeStyleBasedOnStatusBarStyle setup style by current status bar style
 *  BugseeStyleDark when you have UIStatusBarStyleLightContent and BugseeStyleDefault when you have UIStatusBarStyleDefault
 */
extern NSString *const _Nonnull BugseeStyleSystemDefault,
        *const _Nonnull BugseeStyleDefault,
        *const _Nonnull BugseeStyleDark,
        *const _Nonnull BugseeStyleBasedOnStatusBarStyle;

extern NSString *const _Nonnull BugseeShakeToReportKey,
        *const _Nonnull BugseeMaxRecordingTimeKey,
        *const _Nonnull BugseeScreenshotToReportKey,
        *const _Nonnull BugseeCrashReportKey,
        *const _Nonnull BugseeDetectAppExitKey,
        *const _Nonnull BugseeKillDetectionKey,
        *const _Nonnull BugseeAppLaunchCrashDetectionKey,
        *const _Nonnull BugseeFrameRateKey,
        *const _Nonnull BugseeMaxFrameRateKey,
        *const _Nonnull BugseeMinFrameRateKey,
        *const _Nonnull BugseeMonitorNetworkKey,
        *const _Nonnull BugseeSanitizeNetworkDataKey,
        *const _Nonnull BugseeMonitorWebSocketKey,
        *const _Nonnull BugseeMonitorDiskSpaceKey,
        *const _Nonnull BugseeStatusBarInfoKey,
        *const _Nonnull BugseeVideoEnabledKey,
        *const _Nonnull BugseeScreenshotEnabledKey,
        *const _Nonnull BugseeViewHierarchyEnabledKey,
//        *const _Nonnull BugseeDataEncryptionKey,
        *const _Nonnull BugseeStyleKey,
        *const _Nonnull BugseeEnableMachExceptionsKey,
        *const _Nonnull BugseeEnableOnDeviceSymbolicationKey,
        *const _Nonnull BugseeReportPrioritySelectorKey,
        *const _Nonnull BugseeDefaultCrashPriorityKey,
        *const _Nonnull BugseeDefaultErrorPriorityKey,
        *const _Nonnull BugseeDefaultBugPriorityKey,
        *const _Nonnull BugseeCaptureLogsKey,
        *const _Nonnull BugseeCaptureOSLogsKey,
        *const _Nonnull BugseeCaptureAVPlayerKey,
        *const _Nonnull BugseeWifiOnlyUploadKey,
        *const _Nonnull BugseeMaxDataSizeKey,
        *const _Nonnull BugseeMaxNetworkBodySizeKey,
        *const _Nonnull BugseeVideoScaleKey,
        *const _Nonnull BugseeBuildTargetKey,
        *const _Nonnull BugseeBuildTypeKey,
        *const _Nonnull BugseeCaptureDeviceAndNetworkNames,
        *const _Nonnull BugseeMonitorBluetoothStatusKey,
        *const _Nonnull BugseePerformanceMonitoringKey,
        *const _Nonnull BugseePerformanceSampleRateKey,
        *const _Nonnull BugseePerformanceAdaptiveSamplingKey,
        *const _Nonnull BugseeReportSummaryRequiredKey,
        *const _Nonnull BugseeReportDescriptionRequiredKey,
        *const _Nonnull BugseeReportEmailRequiredKey,
        *const _Nonnull BugseeReportLabelsEnabledKey,
        *const _Nonnull BugseeReportLabelsRequiredKey;

/**
 *  We can only show you request/response bodies with size less than 5 kb
 */
extern NSString *const _Nonnull BugseeNetworkBodySizeTooLarge;

/**
 *  We support json, text and xml formats
 */
extern NSString *const _Nonnull BugseeNetworkBodyUnsupportedContentType;

/**
 *  No content type on request/response
 */
extern NSString *const _Nonnull BugseeNetworkBodyNoContentType;

/**
 *  We support data only in UTF8 string encoding
 */
extern NSString *const _Nonnull BugseeNetworkBodyCantReadData;

//Network event types, this constants are used in BugseeNetworkEvent bugseeNetworkEventType property.
//see documentation page to learn more https://docs.bugsee.com/sdk/ios/privacy/

extern NSString *const _Nonnull BugseeNetworkEventBegin;
extern NSString *const _Nonnull BugseeNetworkEventComplete;
extern NSString *const _Nonnull BugseeNetworkEventCancel;
extern NSString *const _Nonnull BugseeNetworkEventError;

extern NSString *const _Nonnull BugseeWebSocketEventOpen;
extern NSString *const _Nonnull BugseeWebSocketEventSend;
extern NSString *const _Nonnull BugseeWebSocketEventMessage;
extern NSString *const _Nonnull BugseeWebSocketEventClose;
extern NSString *const _Nonnull BugseeWebSocketEventError;

extern NSString *const _Nonnull BugseeReportTypeBug;
extern NSString *const _Nonnull BugseeReportTypeCrash;
extern NSString *const _Nonnull BugseeReportTypeError;


extern NSString *const _Nonnull BugseeAttachmentOverrideLabels;

#endif // !BUGSEE_CONSTANTS_H
