//
//  BGSTransactionData.h
//  BugseeLib
//
//  Copyright © 2026 Bugsee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BGSSpan.h"
#import "BGSSpanData.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * Immutable serializable snapshot of a complete transaction (the root
 * span) plus its descendant span tree, flattened into `spans`.
 *
 * Each instance corresponds to one entry in the `transactions` array of
 * the bundle's `performance.json` file. Snapshots produced by
 * `flushActiveTransactions` carry `isSnapshot=YES` and a null
 * `endTimestampMs`; final snapshots produced when a transaction finishes
 * carry `isSnapshot=NO`.
 */
@interface BGSTransactionData : NSObject

@property(readonly, copy) NSString *traceId;
@property(readonly, copy) NSString *name;
@property(readonly, copy) NSString *operation;
@property(readonly) BGSSpanStatus status;
@property(readonly) int64_t startTimestampMs;
@property(readonly) int64_t endTimestampMs;
@property(readonly) int64_t durationNanos;
@property(readonly, getter=isSnapshot) BOOL snapshot;
@property(readonly, getter=isSampled) BOOL sampled;
@property(readonly, copy) NSString *appVersion;
@property(readonly) int appBuild;
@property(readonly, copy) NSArray<BGSSpanData *> *spans;
@property(readonly, copy) NSDictionary<NSString *, id> *attributes;

- (instancetype)initWithTraceId:(NSString *)traceId
                            name:(NSString *)name
                       operation:(NSString *)operation
                          status:(BGSSpanStatus)status
                startTimestampMs:(int64_t)startTimestampMs
                  endTimestampMs:(int64_t)endTimestampMs
                   durationNanos:(int64_t)durationNanos
                        snapshot:(BOOL)snapshot
                         sampled:(BOOL)sampled
                      appVersion:(NSString *)appVersion
                        appBuild:(int)appBuild
                           spans:(NSArray<BGSSpanData *> *)spans
                      attributes:(NSDictionary<NSString *, id> *)attributes NS_DESIGNATED_INITIALIZER;

- (instancetype)init NS_UNAVAILABLE;

- (NSDictionary<NSString *, id> *)toDictionary;

@end

NS_ASSUME_NONNULL_END
