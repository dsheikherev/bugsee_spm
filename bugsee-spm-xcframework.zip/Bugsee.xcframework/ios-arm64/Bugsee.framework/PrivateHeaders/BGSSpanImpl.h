//
//  BGSSpanImpl.h
//  BugseeLib
//
//  Copyright © 2026 Bugsee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BGSSpan.h"
#import "BGSSpanData.h"

NS_ASSUME_NONNULL_BEGIN

@class BGSSpanImpl;

/**
 * Invoked once when a span (or transaction) finishes — including the
 * cascade-finish triggered by a parent's finish. Always delivered exactly
 * once per span.
 */
typedef void (^BGSSpanFinishCallback)(BGSSpanImpl *span);

/**
 * Concrete tree-node implementation of BGSSpan. Internal — providers and
 * the public Bugsee.startSpan(...) entry point hand back the protocol type,
 * never this class.
 *
 * Mutable state (status, attributes, end timestamp, children, finished
 * flag) is guarded by a per-instance os_unfair_lock. Identity fields
 * (spanId, traceId, parentSpanId, startTimestampMs, startUptimeNs) are
 * immutable after init.
 */
@interface BGSSpanImpl : NSObject <BGSSpan>

- (instancetype)initWithSpanId:(NSString *)spanId
                       traceId:(NSString *)traceId
                  parentSpanId:(nullable NSString *)parentSpanId
                        parent:(nullable BGSSpanImpl *)parent
                          root:(nullable BGSSpanImpl *)root
                     operation:(NSString *)operation
               spanDescription:(nullable NSString *)spanDescription
                    attributes:(nullable NSDictionary<NSString *, id> *)attributes
              startTimestampMs:(int64_t)startTimestampMs
                 startUptimeNs:(uint64_t)startUptimeNs
                finishCallback:(nullable BGSSpanFinishCallback)finishCallback NS_DESIGNATED_INITIALIZER;

- (instancetype)init NS_UNAVAILABLE;

/** ID of the parent span; nil for the root transaction. Captured at construction. */
@property(readonly, copy, nullable) NSString *parentSpanId;

/** Weak reference to the span this span was created from, for parent restoration. */
@property(weak, nullable, readonly) BGSSpanImpl *parentSpan;

/** Weak reference to the root transaction; nil for the root itself. */
@property(weak, nullable, readonly) BGSSpanImpl *rootSpan;

@property(readonly) int64_t startTimestampMs;
@property(readonly) uint64_t startUptimeNs;
@property(readonly) int64_t endTimestampMs;
@property(readonly) uint64_t endUptimeNs;
@property(readonly) int64_t durationNanos;

/**
 * Snapshot this node as a BGSSpanData (no children). Pass the root's
 * startUptimeNs so startOffsetNs can be computed.
 */
- (BGSSpanData *)toSpanDataWithRootStartUptimeNs:(uint64_t)rootStartUptimeNs;

/**
 * Walk this subtree and return a flat DFS list of BGSSpanData snapshots
 * starting with `self` at index 0, followed by descendants in pre-order.
 * Pass the root's `startUptimeNs` so each entry's `startOffsetNs` is
 * computed against the same origin.
 *
 * For a transaction with no children, this yields a single-element list
 * containing the flattened root — matching the wire format the rest of
 * the SDK family produces.
 */
- (NSArray<BGSSpanData *> *)collectSpanDataWithRootStartUptimeNs:(uint64_t)rootStartUptimeNs;

@end

/** Generate a 32-character lowercase hex span/trace ID (UUID with hyphens stripped). */
FOUNDATION_EXPORT NSString *BGSSpanGenerateUuidHex(void);

/** Read the current uptime in nanoseconds via CLOCK_UPTIME_RAW (iOS 10+). */
FOUNDATION_EXPORT uint64_t BGSSpanCurrentUptimeNs(void);

NS_ASSUME_NONNULL_END
