//
//  BGSSpanData.h
//  BugseeLib
//
//  Copyright © 2026 Bugsee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BGSSpan.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * Immutable serializable snapshot of a child span — one node in a
 * transaction's span tree. Root transactions are represented by
 * `BGSTransactionData`. The field set is what gets serialized into
 * `performance.json` inside the report bundle.
 */
@interface BGSSpanData : NSObject

@property(readonly, copy) NSString *spanId;
@property(readonly, copy, nullable) NSString *parentSpanId;
@property(readonly, copy) NSString *operation;
@property(readonly, copy, nullable) NSString *spanDescription;
@property(readonly) BGSSpanStatus status;
@property(readonly) int64_t startTimestampMs;
@property(readonly) int64_t endTimestampMs;
@property(readonly) int64_t durationNanos;
@property(readonly) int64_t startOffsetNs;
@property(readonly, getter=isFinished) BOOL finished;
@property(readonly, copy) NSDictionary<NSString *, id> *attributes;

- (instancetype)initWithSpanId:(NSString *)spanId
                  parentSpanId:(nullable NSString *)parentSpanId
                     operation:(NSString *)operation
               spanDescription:(nullable NSString *)spanDescription
                        status:(BGSSpanStatus)status
              startTimestampMs:(int64_t)startTimestampMs
                endTimestampMs:(int64_t)endTimestampMs
                 durationNanos:(int64_t)durationNanos
                 startOffsetNs:(int64_t)startOffsetNs
                      finished:(BOOL)finished
                    attributes:(NSDictionary<NSString *, id> *)attributes NS_DESIGNATED_INITIALIZER;

- (instancetype)init NS_UNAVAILABLE;

/**
 * Serialize as a plain NSDictionary suitable for JSON encoding.
 * Status is encoded as one of the literal strings: "OK", "ERROR",
 * "TIMEOUT", "CANCELLED", "DEADLINE_EXCEEDED", "UNKNOWN".
 */
- (NSDictionary<NSString *, id> *)toDictionary;

@end

/**
 * Map a status enum to its wire-format string label. Exposed so
 * `BGSTransactionData` can share the same formatter.
 */
FOUNDATION_EXPORT NSString *BGSSpanStatusToString(BGSSpanStatus status);

NS_ASSUME_NONNULL_END
