//
//  BGSAdaptiveSampler.h
//  BugseeLib
//
//  Copyright © 2026 Bugsee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BGSTransactionData.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * Lightweight scorer that promotes "interesting" transactions into the
 * standalone upload pipeline even when the static sample rate did not
 * select them.
 *
 * Per-operation duration statistics are maintained online via Welford's
 * algorithm. Three signals combine into a [0, 1] score:
 *   - non-OK status (strong positive),
 *   - duration z-score against the rolling per-operation baseline (saturating),
 *   - span-tree complexity (small positive).
 *
 * A transaction is promoted when the score meets the configured threshold.
 *
 * Thread-safety: per-operation stats are updated under each stats instance's
 * own os_unfair_lock; the operations map is guarded by a separate lock.
 * The operations map is capped at 256 entries to prevent unbounded growth
 * from high-cardinality operation names.
 */
@interface BGSAdaptiveSampler : NSObject

- (instancetype)initWithThreshold:(float)threshold NS_DESIGNATED_INITIALIZER;
- (instancetype)init NS_UNAVAILABLE;

/**
 * Score the transaction, observe its duration as a side effect, and
 * return YES if the score meets the promotion threshold.
 */
- (BOOL)shouldPromote:(BGSTransactionData *)data;

/** Compute the [0, 1] interestingness score without observing. Exposed for tests. */
- (float)scoreForData:(BGSTransactionData *)data;

@end

NS_ASSUME_NONNULL_END
