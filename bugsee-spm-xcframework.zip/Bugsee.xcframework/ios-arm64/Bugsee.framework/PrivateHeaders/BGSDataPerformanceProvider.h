//
//  BGSDataPerformanceProvider.h
//  BugseeLib
//
//  Copyright © 2026 Bugsee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BGSPerformanceProvider.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * APM auto-instrumentation for `NSData` file reads and writes. Each
 * matching call becomes a `file.read` or `file.write` child span on the
 * currently-active transaction. If no transaction is in scope on the
 * calling thread, no span is produced — file I/O is "ambient" without
 * a parent.
 *
 * Swizzles are installed on first start and stay installed for the
 * process lifetime; `stop` flips an internal flag so the swizzles
 * become no-ops, but the IMPs themselves are not unhooked (Apple's
 * runtime makes that risky).
 *
 * Pure Objective-C method swizzling on Foundation classes — no
 * `fishhook` / dyld symbol rebinding. Swift's `Data(contentsOf:)`,
 * `Data(contentsOfFile:)` and `data.write(to:)` are bridged to the
 * NSData methods we cover here.
 *
 * Limitations:
 *   - Only NSData read/write paths are covered. Raw POSIX `open` /
 *     `read` / `write` and `NSFileManager` operations are not (would
 *     require a separate provider).
 *   - Spans only attach to a transaction if that transaction is the
 *     active span on the SAME thread (TLS lookup). File I/O on a
 *     background queue won't pick up a transaction started on the
 *     main thread.
 *   - SDK-internal file writes (paths under Bugsee's data directory)
 *     are excluded to avoid noisy self-instrumentation. A per-thread
 *     reentrancy guard is the additional safety net.
 */
@interface BGSDataPerformanceProvider : NSObject <BGSPerformanceProvider>

+ (instancetype)sharedProvider;

@end

NS_ASSUME_NONNULL_END
