//
//  BGSSpanContextHolder.h
//  BugseeLib
//
//  Copyright © 2026 Bugsee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BGSSpan.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * Thread-local storage for the currently active span. New spans created via
 * `Bugsee.startSpan(...)` use the value here to resolve their parent.
 *
 * Backed by `pthread_setspecific` — lookup is lock-free on the hot path.
 *
 * Limitation: does not auto-propagate across `dispatch_async`. If you hop a
 * block to another queue and want it to inherit the span, capture the span
 * explicitly and call `[parent startChildSpan...]` inside the block.
 */
@interface BGSSpanContextHolder : NSObject

+ (nullable id<BGSSpan>)current;
+ (void)setCurrent:(nullable id<BGSSpan>)span;
+ (void)clear;

@end

NS_ASSUME_NONNULL_END
