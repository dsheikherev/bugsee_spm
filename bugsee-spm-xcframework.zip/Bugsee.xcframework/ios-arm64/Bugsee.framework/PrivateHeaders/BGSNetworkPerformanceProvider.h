//
//  BGSNetworkPerformanceProvider.h
//  BugseeLib
//
//  Copyright © 2026 Bugsee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BGSPerformanceProvider.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * APM auto-instrumentation for `NSURLSession` traffic. Each network task
 * becomes a detached `http.client` transaction, keyed by the same tracking
 * ID the existing `BGSURLSessionEventsSwizzling` plumbing already assigns.
 *
 * The provider does not install its own swizzles. Instead, it exposes
 * three C-function hook points that `BGSURLSessionEventsSwizzling.m`
 * calls alongside its existing network-event capture. When APM is
 * disabled, the hook calls fall through cheaply (one BOOL check).
 */
@interface BGSNetworkPerformanceProvider : NSObject <BGSPerformanceProvider>

+ (instancetype)sharedProvider;

@end

NS_ASSUME_NONNULL_END

#pragma mark - C hook entry points (called from BGSURLSessionEventsSwizzling)

/**
 * Begin tracing an HTTP request. Idempotent — calling twice with the same
 * tracking ID is a no-op (we keep the first transaction). All arguments
 * may be nil; the call returns immediately if APM is disabled.
 */
FOUNDATION_EXPORT void Bugsee_PerformanceBeginRequest(NSString *_Nullable trackingID,
                                                      NSString *_Nullable method,
                                                      NSURL *_Nullable url);

/**
 * Finish tracing the request. Status comes from `statusCode` (2xx/3xx → OK,
 * 4xx/5xx → Error). If `error` is non-nil, status is forced to Error
 * regardless of `statusCode`. `responseBytes` populates the
 * `http.response_size_bytes` attribute.
 */
FOUNDATION_EXPORT void Bugsee_PerformanceFinishRequest(NSString *_Nullable trackingID,
                                                       NSInteger statusCode,
                                                       int64_t responseBytes,
                                                       NSError *_Nullable error);

/** Cancel-ended variant. The transaction finishes with Cancelled status. */
FOUNDATION_EXPORT void Bugsee_PerformanceCancelRequest(NSString *_Nullable trackingID);
