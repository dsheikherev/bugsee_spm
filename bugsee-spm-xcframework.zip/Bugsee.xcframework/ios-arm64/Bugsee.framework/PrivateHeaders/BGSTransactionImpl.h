//
//  BGSTransactionImpl.h
//  BugseeLib
//
//  Copyright © 2026 Bugsee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BGSTransaction.h"
#import "BGSSpanImpl.h"
#import "BGSTransactionData.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * Root span of a trace; concrete implementation of BGSTransaction.
 * Internal type — providers and Bugsee.startTransaction(...) hand back the
 * `BGSTransaction` protocol.
 */
@interface BGSTransactionImpl : BGSSpanImpl <BGSTransaction>

- (instancetype)initWithName:(NSString *)name
                    operation:(NSString *)operation
                      sampled:(BOOL)sampled
                   attributes:(nullable NSDictionary<NSString *, id> *)attributes
               finishCallback:(nullable BGSSpanFinishCallback)finishCallback NS_DESIGNATED_INITIALIZER;

- (instancetype)initWithSpanId:(NSString *)spanId
                       traceId:(NSString *)traceId
                  parentSpanId:(nullable NSString *)parentSpanId
                        parent:(nullable BGSSpanImpl *)parent
                          root:(nullable BGSSpanImpl *)root
                     operation:(NSString *)operation
               spanDescription:(nullable NSString *)spanDescription
                    attributes:(nullable NSDictionary<NSString *, id> *)attributes
              startTimestampMs:(int64_t)startTimestampMs
                 startUptimeNs:(uint64_t)startUptimeNs
                finishCallback:(nullable BGSSpanFinishCallback)finishCallback NS_UNAVAILABLE;

/**
 * Promote a transaction that lost the static sampling draw — invoked by
 * the adaptive sampler. Idempotent.
 */
- (void)markSampled;

/**
 * Build a serializable snapshot of this transaction and its complete
 * subtree. `snapshot=YES` indicates an in-flight capture (transaction is
 * not yet finished).
 */
- (BGSTransactionData *)toTransactionDataAsSnapshot:(BOOL)snapshot;

@end

NS_ASSUME_NONNULL_END
