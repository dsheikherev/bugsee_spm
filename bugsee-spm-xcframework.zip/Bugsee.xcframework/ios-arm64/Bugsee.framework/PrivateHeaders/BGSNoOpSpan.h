//
//  BGSNoOpSpan.h
//  BugseeLib
//
//  Copyright © 2026 Bugsee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BGSSpan.h"
#import "BGSTransaction.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * Singleton no-op implementations of BGSSpan / BGSTransaction.
 * Returned from public APIs when APM is disabled. Every method is a no-op
 * and fluent setters return the same singleton — zero allocations on the
 * hot path.
 *
 *     spanId / traceId : @"0"
 *     status           : BGSSpanStatusUnknown
 *     finished         : YES
 *     attributes       : empty dictionary
 */
@interface BGSNoOpSpan : NSObject <BGSSpan>
+ (instancetype)sharedNoOp;
@end

@interface BGSNoOpTransaction : NSObject <BGSTransaction>
+ (instancetype)sharedNoOp;
@end

NS_ASSUME_NONNULL_END
