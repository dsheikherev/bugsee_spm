//
//  BGSSpanFactory.h
//  BugseeLib
//
//  Copyright © 2026 Bugsee. All rights reserved.
//

#ifndef BGS_SPAN_FACTORY_H
#define BGS_SPAN_FACTORY_H

#import <Foundation/Foundation.h>
#import "BGSSpan.h"
#import "BGSTransaction.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * Internal contract handed to performance providers so they can mint
 * spans and transactions without seeing BGSPerformanceCoordinator.
 *
 * `startTransaction:operation:` sets the new transaction as the current
 * span on the calling thread (TLS). `startDetachedTransaction:operation:`
 * skips that step — used by auto-instrumentation providers that manage
 * their own lifecycle independently of any caller's thread context.
 */
@protocol BGSSpanFactory <NSObject>

- (id<BGSSpan>)startSpanWithOperation:(NSString *)operation
                          description:(nullable NSString *)description;

- (id<BGSSpan>)startSpanWithOperation:(NSString *)operation
                          description:(nullable NSString *)description
                           attributes:(nullable NSDictionary<NSString *, id> *)attributes;

- (id<BGSTransaction>)startTransactionWithName:(NSString *)name
                                     operation:(NSString *)operation;

- (id<BGSTransaction>)startTransactionWithName:(NSString *)name
                                     operation:(NSString *)operation
                                    attributes:(nullable NSDictionary<NSString *, id> *)attributes;

- (id<BGSTransaction>)startDetachedTransactionWithName:(NSString *)name
                                             operation:(NSString *)operation;

@end

NS_ASSUME_NONNULL_END

#endif // !BGS_SPAN_FACTORY_H
