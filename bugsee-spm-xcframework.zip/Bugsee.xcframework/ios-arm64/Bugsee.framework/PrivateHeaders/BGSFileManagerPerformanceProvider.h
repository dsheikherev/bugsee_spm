//
//  BGSFileManagerPerformanceProvider.h
//  BugseeLib
//
//  Copyright © 2026 Bugsee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BGSPerformanceProvider.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * APM auto-instrumentation for `NSFileManager` operations. Each
 * swizzled call becomes a child span on the currently-active
 * transaction with one of:
 *
 *   `file.create`  — createFileAtPath:contents:attributes:
 *   `file.delete`  — removeItemAtPath:error: / removeItemAtURL:error:
 *   `file.copy`    — copyItemAtPath:toPath:error: / copyItemAtURL:toURL:error:
 *   `file.move`    — moveItemAtPath:toPath:error: / moveItemAtURL:toURL:error:
 *   `file.mkdir`   — createDirectoryAt(Path|URL):withIntermediateDirectories:...
 *
 * Sibling of `BGSFileIOPerformanceProvider` (which covers `NSData`
 * read/write). The two are kept separate so consumers can reason about
 * each surface independently and so future revisions can gate them
 * with finer-grained options if needed.
 *
 * Pure Objective-C method swizzling. No fishhook / dyld symbol
 * rebinding. Same TLS-based parent-lookup limitation as the FileIO
 * provider: file-manager calls on a background queue won't pick up a
 * transaction started on a different thread.
 */
@interface BGSFileManagerPerformanceProvider : NSObject <BGSPerformanceProvider>

+ (instancetype)sharedProvider;

@end

NS_ASSUME_NONNULL_END
