#import <Foundation/Foundation.h> 

OBJC_EXPORT NSString * bgs_commonJSInjectString(void);
OBJC_EXPORT NSString * bgs_shaderMetalInjectString(void);
