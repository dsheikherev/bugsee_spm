//
//  BGSPerformanceCoordinator.h
//  BugseeLib
//
//  Copyright © 2026 Bugsee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BGSSpanFactory.h"
#import "BGSPerformanceProvider.h"
#import "BGSTransactionData.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * Central orchestrator for the APM subsystem. Singleton — owned by
 * `BGSRecordingCoordinator`, which calls `launch` / `stop` in lockstep
 * with the recording lifecycle.
 *
 * Implements `BGSSpanFactory` so it backs the public Bugsee.startSpan(...) /
 * startTransaction(...) entry points. Auto-instrumentation providers
 * receive the factory at start time and never see the coordinator
 * directly.
 *
 * Every transaction (sampled or not) is delivered to the capture pipeline
 * so it appears in bug-report bundles. Sampling and the adaptive promoter
 * only gate the standalone upload pipeline (currently deferred).
 */
@interface BGSPerformanceCoordinator : NSObject <BGSSpanFactory>

+ (instancetype)sharedManager;

@property(nonatomic, readonly, getter=isRunning) BOOL running;
@property(nonatomic, readonly, getter=isEnabled) BOOL enabled;

/**
 * Read launch options, build sampler, register built-in providers, and
 * start each provider. Idempotent — repeated calls are no-ops if running.
 */
- (void)launch;

/** Stop all providers and reset internal state. Idempotent. */
- (void)stop;

/**
 * Subscribe a provider. Called at most once per provider per launch
 * cycle. If the coordinator is already running, the provider is started
 * immediately; otherwise it's started by the next `launch`.
 */
- (void)registerProvider:(id<BGSPerformanceProvider>)provider;

/** Remove a provider by its identifier. Stops it first if it's running. */
- (void)unregisterProviderWithIdentifier:(NSString *)identifier;

/**
 * Pin a completed transaction so its data is re-emitted into every report
 * snapshot — used by the startup provider so the launch trace appears in
 * every bundle even after the original event has rolled out of the buffer.
 */
- (void)pinTransactionData:(BGSTransactionData *)data;

/**
 * Walk active and pinned transactions and emit their `BGSTransactionData`
 * snapshots into the event stream. Called from `BGSRecordingCoordinator`
 * immediately before bundle assembly.
 */
- (void)flushActiveTransactions;

/**
 * Currently-active span on the calling thread (TLS), with stale-finished
 * span cleanup. Returns nil if APM is disabled or no transaction is in
 * scope.
 */
- (nullable id<BGSSpan>)activeSpan;

@end

NS_ASSUME_NONNULL_END
