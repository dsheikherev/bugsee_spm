//
//  BGSPerformanceProvider.h
//  BugseeLib
//
//  Copyright © 2026 Bugsee. All rights reserved.
//

#ifndef BGS_PERFORMANCE_PROVIDER_H
#define BGS_PERFORMANCE_PROVIDER_H

#import <Foundation/Foundation.h>
#import "BGSSpanFactory.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * Lifecycle contract for an APM auto-instrumentation provider.
 * Each provider is identified by a unique string and is given a span
 * factory at start time so it can mint spans without seeing the
 * coordinator. Failures are isolated by the coordinator — one provider
 * raising during start/stop will not affect others.
 */
@protocol BGSPerformanceProvider <NSObject>

@property(readonly) NSString *identifier;
@property(readonly, getter=isRunning) BOOL running;

- (void)startWithFactory:(id<BGSSpanFactory>)factory;
- (void)stop;

@end

NS_ASSUME_NONNULL_END

#endif // !BGS_PERFORMANCE_PROVIDER_H
