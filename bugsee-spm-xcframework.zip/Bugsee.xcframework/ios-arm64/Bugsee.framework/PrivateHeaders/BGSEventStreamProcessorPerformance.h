//
//  BGSEventStreamProcessorPerformance.h
//  BugseeLib
//
//  Copyright © 2026 Bugsee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BGSEventStreamProcessor.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * Stream processor for `DumpTypePerformance` events.
 *
 * Each ingested event is a wrapper of the form
 *   `{ __dump_type, name, timestamp, transaction: {...} }`
 *
 * The processor buffers per-`traceId` and applies the dedup rule
 * "completed wins over snapshot for the same traceId". Snapshots emitted
 * by `BGSPerformanceCoordinator.flushActiveTransactions` are superseded
 * by the same trace's final completion when both land in the same
 * recording window.
 *
 * On `finish`, the kept transaction dictionaries are written **unwrapped**
 * into the JSON output's `transactions` root array, so the bundle's
 * `performance.json` matches the wire-format schema directly.
 */
@interface BGSEventStreamProcessorPerformance : NSObject <BGSEventStreamProcessor>

@end

NS_ASSUME_NONNULL_END
