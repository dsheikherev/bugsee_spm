//
//  BugseeExceptionLoggingOptions.h
//  Bugsee
//
//  Created by Denis Sheikherev on 26.05.2023.
//  Copyright © 2016-2023 Bugsee. All rights reserved.
//

#ifndef BugseeExceptionLoggingOptions_h
#define BugseeExceptionLoggingOptions_h

#import <Foundation/Foundation.h>

extern NSString *const _Nonnull BugseeMergingRulesSkipFramesKey;

@interface BugseeExceptionLoggingOptions : NSObject

/**
 * Labels which should be set for the generated issue in web dashboard.
 */
@property(nonatomic, strong) NSArray<NSString *> *_Nullable labels;

/**
 * Flag which instructs SDK either include or exclude video
 * from the final generated report bundle.
 * Useful if you want to force a video-less report.
 */
@property(nonatomic, assign) BOOL includeVideo;

/**
 * Rules that specify how, for example, exceptions should be grouped on web dashboard.
 * Specify 'BugseeMergingRulesSkipFramesKey' in mergingRules to skip the specified number of frames when comparing stack traces during reports grouping.
 * Doing so will allow you to group exceptions from different origins.
 *
 * Example:
 *
 * BugseeExceptionLoggingOptions *exceptionLoggingOptions = [BugseeExceptionLoggingOptions new];
 *
 * NSDictionary *mergingRules = @{
 *   // Set the number of top frames to be removed from the stack trace.
 *   BugseeMergingRulesSkipFramesKey: @1
 * };
 *
 * exceptionLoggingOptions.mergingRules = mergingRules;
 * [Bugsee logException:ex options:exceptionLoggingOptions];
 *
 */
@property(nonatomic, strong) NSDictionary *_Nullable mergingRules;

@end

#endif /* BugseeExceptionLoggingOptions_h */
