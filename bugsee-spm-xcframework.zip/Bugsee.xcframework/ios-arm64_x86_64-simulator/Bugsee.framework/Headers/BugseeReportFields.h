//
//  BugseeReportFields.h
//  Bugsee
//
//  Created by Denis Sheikherev on 01.12.2022.
//  Copyright © 2016-2023 Bugsee. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "BugseeConstants.h"

/**
 * Class to be used in delegate methods:
 * -[BugseeDelegate bugseeAddFieldsBeforeReportCreated],
 * -[BugseeDelegate bugseeCheckFieldsAfterReportCreated:completionHandler:]
 * of the BugseeDelegate protocol.
 * Use these delegate methods to modify report fields such as summary, description, labels
 * before or after Report ViewController is presented.
 */
@interface BugseeReportFields : NSObject

+ (instancetype _Nonnull)reportFieldsWith:(NSString *_Nullable)summary
                              description:(NSString *_Nullable)description
                                 severity:(BugseeSeverityLevel)severity
                                   labels:(NSArray<NSString *> *_Nullable)labels;

/**
 * Short summary field of the report
 *
 * @return NSString
 */
@property(nonatomic, strong) NSString *_Nullable summary;

/**
 * Detailed descirption field of the report
 *
 * @return NSString
 */
@property(nonatomic, strong) NSString *_Nullable reportDescription;

/**
 * Severity field of the report
 */
@property(nonatomic, assign) BugseeSeverityLevel severity;

/**
 * Array containing all the associated labels of the report
 *
 * @return NSArray<NSString*>
 */
@property(nonatomic, strong) NSArray<NSString *> *_Nullable labels;

@end
